# Text Free Browsing

Hides all text on every website
Text Free Browsing is an extension that can hide text while you surf the web. You can turn it on or off at any moment. <br/>

http://www.textfreebrowsing.com/<br/>

An art project by Rafaël Rozendaal & Jonas Lund <br/>
http://www.newrafael.com <br/>
http://www.jonaslund.biz <br/>